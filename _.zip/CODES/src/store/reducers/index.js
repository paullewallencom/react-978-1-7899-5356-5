import { APIReducer } from './api_reducer';
import { combineReducers } from 'redux';

export default combineReducers({ APIReducer });